<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_PSInvoiceSale.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHk6ndwsOF9/BTWJv4z4P8KoNYtdIbCjiW3CRKwD" +
				"YpTlZqJOjeVHY+IFNLVt3XYKhcdtP/r1Uy1g0kq8cT31yDcTiL+H0neQc0i1NtB4FtjXcyHQkdjGGFXt" +
				"c/8CvOH++K2BLP0OYQq7TeegevcJc951rIsJGbuGZC4wFM8GZjRdLmfZr+lJODZdOuV3+boCDj9m+2jx" +
				"IOPbzu9+hKpUBnZHV1N52zvRjqNPj1QBYfobUgdCDQwP2CfdHCEeswHcgurmj3qgWPONhXJ8be+Qe3ZT" +
				"qP2zB1iLcdBhKT3syVl2Yig2f27KY37SZ6L1eDYQoSdTNIpjCH6pzY+BSfbBvbyYPYx/ft319zULA5vk" +
				"bhZZ7a5a/4jBvD7XNhRqdPKvUXoL52nL3eu0NpU4S1E9P/2Z8Tyf+nJQrAPRfaCSCrk1ltPqLTZXzMdW" +
				"kN6pNxD6hFZ5mkAOWYJL7tp9Ysck4rtVV/aZmyR7VzhjWTYZLciGNkVQZGRU7UrnVHyW3IxS4rJvJXcd" +
				"HIkZwa1LmD+fDRJlR2iDbJsdkzyuWypZxHwpO8Zajne8EHFPbC7i6uKkNq9uh2F1RjDIm91eBgPrIb8i" +
				"6rML1oleHQkgHmAUPeuCYheQIIO+t7iyl2V4MV2hcv2pyiAMBo+svtgzUbaNs0pX4svdxUkQzwkIkFtn" +
				"53mPloGvp0d5c4HF/Prfv8zelgMA+Elzq8yx7fycuStprCuiJ9TPQ3aUMfybuDU+ixlGjnN/N8QJ5FJR" +
				"rr/Yi02NJ5O17eWaEg1tVWy6Mb7GcIu2ePD6x4noscI0iVjomRmD28OdCNUlcKuBZ5BuTq5QvUYYxyrj" +
				"QmbvUT1ZN9DHMRBKWgzPAg40bZGddImvXi70u+njQMlkDcL19eTpjHl8P9WCRdbUXVpQogkrA9hey1Fi" +
				"5fqGhtgaRkmYbiFaX9rp6YSdMDh4VepvUitJL7OsADgq+C3J9EFEWqP3zVVXkuO55KPwyuXip6EARPn/" +
				"TmqZiZrYduc4yNXJtjNgX/F6o40=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_PSInvoiceSale.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 3;
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "S22000010000006";
			report.dictionary.variables.getByName("SP_tStaPrn").valueObject = "1";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "00001";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>